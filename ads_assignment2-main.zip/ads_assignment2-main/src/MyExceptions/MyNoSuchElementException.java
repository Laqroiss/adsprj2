package MyExceptions;

public class MyNoSuchElementException extends RuntimeException{
    public MyNoSuchElementException(String message){
        super(message);
    }
}
